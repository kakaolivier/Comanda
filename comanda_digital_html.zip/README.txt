COMANDA DIGITAL — HTML
Abra index.html no navegador.

Fluxo demonstrativo:
- Login -> Painel da Cozinha
- mesas.html -> seleção/abertura de comanda
- novo-pedido.html -> adiciona itens, calcula total e envia para cozinha
- cadastro.html -> cadastro de usuário

Observação: os dados são apenas demonstrativos e ficam no localStorage do navegador.
